bin=/data/biouser1/SOYBEAN/bin
file="snp indel"
dir="/data/biouser1/SOYBEAN/01.snp"
output=/data/biouser1/SOYBEAN/02.annovar
for i in {1..20};do
echo -n "" >$output/runAnnovar.$i.sh
for f in $file;do echo "
table_annovar.pl $dir/$f/$i.$f.vcf.gz /data/biouser1/SOYBEAN/genomes/ -buildver Glycine_max.Glycine_max_v2.0.40 -out $output/$i.$f\_multianno.txt -remove -protocol refGene -operation g -nastring . -vcfinput
mv $output/$i.$f\_multianno.txt.Glycine_max.Glycine_max_v2.0.40_multianno.txt $output/$i.$f.anno.txt
mv $output/$i.$f\_multianno.txt.Glycine_max.Glycine_max_v2.0.40_multianno.vcf $output/$i.$f.anno.vcf
rm $output/$i.$f\_multianno.txt.avinput
cut -f 1-10 $output/$i.$f.anno.txt >$output/$i.$f.anno.bed
gzip $output/$i.$f.anno.txt
gzip $output/$i.$f.anno.vcf" >>$output/runAnnovar.$i.sh
done
done

echo -n "" >$output/snp.annoStat1.sh
for i in {1..20};do
echo "cut -f 1,2,6 $output/$i.snp.anno.bed|sort|uniq|cut -f 3|sed 's/ncRNA_//'|sed 's/;.*//'|sort |uniq -c|grep -v Func.refGene|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/\s/\t/' >$output/$i.snp.anno.stat1" >>$output/snp.annoStat1.sh
done

echo -n "" >$output/snp.annoStat2.sh
for i in {1..20};do
echo "cut -f 1,2,9 $output/$i.snp.anno.bed|sort|uniq|cut -f 3|grep -v '\.'|grep -v 'unknown'|sed 's/ SNV//g'|sed 's/;.*//'|sort|uniq -c|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/\s/\t/' >$output/$i.snp.anno.stat2" >>$output/snp.annoStat2.sh
done

echo -n "" >$output/indel.annoStat1.sh
for i in {1..20};do
echo "cut -f 1,2,6 $output/$i.indel.anno.bed|sort|uniq|cut -f 3|sed 's/ncRNA_//'|sed 's/;.*//g'|sort |uniq -c|grep -v Func.refGene|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/\s/\t/' >$output/$i.indel.anno.stat1" >>$output/indel.annoStat1.sh
done

echo -n "" >$output/indel.annoStat2.sh
for i in {1..20};do
echo "cut -f 1,2,9 $output/$i.indel.anno.bed|sort|uniq|cut -f 3|grep -v '\.'|grep 'frameshift\|stop'|sed 's/;.*//g'|sort|uniq -c |grep -v Func.refGene|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/^\s//'|sed 's/\s/\t/' >$output/$i.indel.anno.stat2" >>$output/indel.annoStat2.sh
done

echo -n "" >$output/cat.annoStat.sh
for i in {1..20};do 
echo "cat $output/$i.snp.anno.stat1 $output/$i.snp.anno.stat2 $output/$i.indel.anno.stat1 $output/$i.indel.anno.stat2|cut -f 1 >$output/$i.cat.anno.stat" >>$output/cat.annoStat.sh
done
echo -n "paste " >>$output/cat.annoStat.sh
for i in {1..20};do
echo -n " $output/$i.cat.anno.stat" >>$output/cat.annoStat.sh
done
echo " >$output/all.anno.stat.tmp" >>$output/cat.annoStat.sh
echo "cat $output/1.snp.anno.stat1 $output/1.snp.anno.stat2 $output/1.indel.anno.stat1 $output/1.indel.anno.stat2|cut -f 2 |paste - $output/all.anno.stat.tmp >$output/all.anno.stat.tsv" >>$output/cat.annoStat.sh
echo "rm $output/all.anno.stat.tmp
rm $output/*.cat.anno.stat" >>$output/cat.annoStat.sh


