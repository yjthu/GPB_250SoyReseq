tools=/public4/home/pgv3101/pipeline/tools
fqdir=/public4/home/pgv3101/2018003/cleandata
output=/public4/home/pgv3101/project/output
fqinfo=/public4/home/pgv3101/project/list.txt
fqsuffix="clean.fq.gz"
fa=/public4/home/pgv3101/pipeline/genomes/Glycine_max.Glycine_max_v2.0.chr.fa

mkdir $output
perl $tools/SoybeanSNP.pl -fqdir $fqdir -fqinfo $fqinfo -fqsuf $fqsuffix -fa $fa -out $output
cp $tools/g_sbatch.s1.sh $output/workflow/step1
cp $tools/g_sbatch.s2.sh $output/workflow/step2

cd $output/workflow/step1
sh g_sbatch.s1.sh
cd $output/workflow/step2
sh g_sbatch.s2.sh
