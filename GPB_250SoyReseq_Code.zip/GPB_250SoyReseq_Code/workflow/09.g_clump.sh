bin=/data/biouser1/SOYBEAN/bin
ped=/data/biouser1/SOYBEAN/03.imputation/soybean.maf05.hapmap
input=/data/biouser1/SOYBEAN/08.GWAS/gwasOutput
genePos=/data/biouser1/SOYBEAN/genomes/Glycine_max.Glycine_max_v2.0.40.gene.pos

echo -n "" >runClump.sh
ls $input/*.csv|while read a;do echo "
cut -f 1,5 -d ',' $a|sed 's/\"//g' |sed 's/ //g'|sed 's/,/\t/g' |sed '1d' |sed '1iSNP\tP' >${a%%.csv}.assoc
plink --file $ped --clump ${a%%.csv}.assoc --clump-p1 0.00001 --clump-p2 0.0001 --clump-r2 0.3 --clump-kb 150 --clump-allow-overlap --out ${a%%.csv}
grep -v NONE ${a%%.csv}.clumped|grep ',' |sort >${a%%.csv}.filtClump
perl $bin/mergeclump.pl ${a%%.csv}.filtClump >${a%%.csv}.mergeClump
perl $bin/mergeRegions.gwas.pl ${a%%.csv}.mergeClump >${a%%.csv}.mergeRegion
perl $bin/geneInGap.gwas.pl ${a%%.csv}.mergeRegion $genePos >${a%%.csv}.mergeRegionGene.xls

" >>runClump.sh;done

