
bin=/data/biouser1/SOYBEAN/bin
dir=/data/biouser1/SOYBEAN/03.imputation
output=/data/biouser1/SOYBEAN/04.tree

echo "perl $bin/plink2fasta.pl $dir/soybean.hapmap.ped >$output/soybean.tree.fa
/storage/PUBLIC/softwarePkg/MEGA7/megacc  -a /storage/PUBLIC/softwarePkg/MEGA7/template.mao -d $output/soybean.tree.fa
" >$output/tree.sh
echo "perl $bin/addGroupToTree.pl ../phenoInfo/sample.info.txt M7CC_Out/NewickExport.new.nwk >M7CC_Out/NewickExport.final.nwk" >>$output/tree.sh


echo "/storage/PUBLIC/softwarePkg/flashpca-master/flashpca --ndim 20 --bfile $dir/plink" >$output/pca.sh
echo "sed 's/\s/\t/g' $output/eigenvectors.txt|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/\t\t/\t/g'|sed 's/^\t//' >$output/eigenvectors.tsv" >>$output/pca.sh
echo "cut -f 1 -d ' ' $dir/plink.fam >$output/pop.info" >>$output/pca.sh
echo "perl $bin/pop.addinfo.pl $dir/../phenoInfo/sample.final.txt $output/pop.info >$output/pop.grp" >>$output/pca.sh
echo "paste $output/pop.grp $output/eigenvectors.tsv >$output/pcaplot.input" >>$output/pca.sh
echo "python pca3D.v2.py $output/pcaplot.input" >>$output/pca.sh
echo "Rscript plotPCA.v2.R $output/eigenvectors.tsv $output/pop.grp" >>$output/pca.sh

echo "python tsne.py" >>$output/pca.sh
echo "sed -i 's/ /\t/g' tsne.tsv" >>$output/pca.sh
echo "paste $output/pop.grp $output/tsne.tsv >$output/tsneplot.input" >>$output/pca.sh
echo "python pca3D.v2.py $output/tsneplot.input" >>$output/pca.sh
echo "Rscript plotPCA.v2.R $output/tsne.tsv $output/pop.grp" >>$output/pca.sh


echo "perl $bin/extractTreeLabels.pl $output/M7CC_Out/NewickExport.nwk |sed 's/_.*//' >$output/pop.order.txt" >$output/structure.sh
echo "perl $bin/popLabels.pl $output/pop.grp $output/pop.order.txt >$output/pop.grp.order" >>$output/structure.sh
for k in {2..5};do echo "python /storage/PUBLIC/softwarePkg/fastStructure-master/structure.py -K $k --input $dir/plink --output $output/K
perl $bin/reorderStructureQ.pl $output/pop.order.txt $output/pop.info  $output/K.$k.meanQ |sed 's/  /\t/g' >$output/order.K.$k.meanQ
" >>$output/structure.sh;done

echo "awk '{print "0.1"}' $output/pop.order.txt >$output/k.gap.txt" >>$output/structure.sh
echo -n "paste " >>$output/structure.sh
for k in {2..5};do
echo -n " $output/order.K.$k.meanQ $output/k.gap.txt " >>$output/structure.sh
done
echo " >$output/k.paste.tsv" >>$output/structure.sh



