bin=/data/biouser1/SOYBEAN/bin
dir=/data/biouser1/SOYBEAN/03.imputation
output=/data/biouser1/SOYBEAN/06.LD


echo "perl $bin/slimPed.pl $dir/soybean.hapmap" >$output/runSlimPed.sh

echo -n "" >$output/runLD.sh
echo "plink --file $dir/soybean.hapmap.slim10 --r2 --ld-window 10000 --ld-window-kb 1000 --ld-window-r2 0.01 --maf 0.05" >>$output/runLD.sh
echo "perl $bin/g_ld_data.pl $output/plink.ld Gm > $output/Gm.ldplotdata" >>$output/runLD.sh
echo "Rscript $bin/plotldDecay.R $output/Gm.ldplotdata" >>$output/runLD.sh


echo -n "" >$output/groupLD.sh
list="landrace cultivar Group1 Group2 Group3 Group4"
for i in $list;do echo "mkdir -p $output/$i
cd $output/$i
plink --file $dir/splitPop/$i.hapmap.slim10 --r2 --ld-window 10000 --ld-window-kb 1000 --ld-window-r2 0.01 --maf 0.05
perl $bin/g_ld_data.pl $output/$i/plink.ld $i >$output/$i.ldplotdata
cd -
" >>$output/groupLD.sh
done

