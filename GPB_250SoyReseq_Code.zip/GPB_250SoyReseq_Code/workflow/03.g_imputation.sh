bin=/data/biouser1/SOYBEAN/bin
dir=/data/biouser1/SOYBEAN/01.snp
output=/data/biouser1/SOYBEAN/03.imputation

echo -n "" >$output/vcf2bgl.sh
for i in {1..20};do 
echo "zcat $dir/snp/$i.snp.vcf.gz|grep -v '##'|perl $bin/vcf2beagle.pl - >$output/$i.snp.bgl" >>$output/vcf2bgl.sh
done

echo -n "" >$output/runBeagle.sh
for i in {1..20};do
echo "java -Xmx215180m -XX:MaxPermSize=215180m -Djava.io.tmpdir=tmp/ -jar /storage/PUBLIC/softwareInstall/beagle.jar unphased=$output/$i.snp.bgl missing=N out=$output/$i" >>$output/runBeagle.sh
done

echo -n "" >$output/bgl2hmp.sh
for i in {1..20};do
echo "perl $bin/bglphasedgz2hmp.pl $dir/snp/$i.snp.vcf.gz $output/$i.$i.snp.bgl.phased.gz >$output/$i.phased.hmp" >>$output/bgl2hmp.sh
done

echo -n "" >$output/hmp2ped.sh
for i in {1..20};do 
echo "sed '1d' $output/$i.phased.hmp >$output/$i.phased.hmp.noh" >>$output/hmp2ped.sh
done
echo -n "cat $output/1.phased.hmp " >>$output/hmp2ped.sh
for i in {2..20};do
echo -n " $output/$i.phased.hmp.noh" >>$output/hmp2ped.sh
done
echo " >$output/soybean.hapmap" >>$output/hmp2ped.sh
echo "
rm $output/*.phased.hmp.noh
perl $bin/hapmap2plink.pl $output/soybean.hapmap $output
plink --file $output/soybean.hapmap --make-bed" >>$output/hmp2ped.sh

echo "mkdir $output/basicStat
perl $bin/basicStatHapmap.pl $output/soybean.hapmap $output/basicStat" >$output/basicStat.sh

