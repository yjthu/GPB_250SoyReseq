bin=/data/biouser1/SOYBEAN/bin
input=/data/biouser1/SOYBEAN/03.imputation
output=/data/biouser1/SOYBEAN/03.imputation/splitPop
list="landrace cultivar Group1 Group2 Group3 Group4"

mkdir -p $output
#for i in $list;do grep $i /data/biouser1/SOYBEAN/phenoInfo/sample.final.txt |cut -f 1 >$output/$i.list;done

echo -n "" >$output/splitHm2ped.sh
for i in $list;do echo "perl $bin/filtHapmapInd.pl $output/$i.list $input/soybean.hapmap >$output/$i.hapmap
perl $bin/hapmap2vcf.v2.pl $output/$i.hapmap >$output/$i.vcf
perl $bin/hapmap2plink.pl $output/$i.hapmap $output
perl $bin/slimPed.pl $output/$i.hapmap " >>$output/splitHm2ped.sh;done

output2=/data/biouser1/SOYBEAN/07.splitPop
mkdir -p $output2
echo -n "" >$output2/IBS.sh
for i in $list;do echo "mkdir -p $output2/$i" >>$output2/IBS.sh
done
for i in $list;do echo "cd $output2/$i
plink --file $output/$i.hapmap --distance ibs flat-missing square
perl $bin/g_ibs_den_data.pl $output2/$i/plink.mibs $i >$output2/$i/$i.ibsvalues
cd -" >>$output2/IBS.sh
done
echo "mkdir -p $output2/Gm
cd $output2/Gm
plink --file $output/../soybean.hapmap --distance ibs flat-missing square
perl $bin/g_ibs_den_data.pl $output2/Gm/plink.mibs max >$output2/Gm/Gm.ibsvalues
cd -">>$output2/IBS.sh


echo -n "" >$output2/ROH.sh
for i in $list;do echo "cd $output2/$i
plink --file $output/$i.hapmap --homozyg  --homozyg-kb 300 --homozyg-snp 1000 --homozyg-het 0.001
cd -" >>$output2/ROH.sh
done

echo -n "" >$output2/AFD.sh
for i in $list;do echo "cd $output2/$i
plink --file $output/$i.hapmap --freq
cd -" >>$output2/AFD.sh
done
echo "perl ../bin/combinPlinkFrq.pl Group1/plink.frq Group2/plink.frq Group3/plink.frq Group4/plink.frq cultivar/plink.frq landrace/plink.frq ../03.imputation/splitPop/Group3.hapmap >combin.frq" >>$output2/AFD.sh

