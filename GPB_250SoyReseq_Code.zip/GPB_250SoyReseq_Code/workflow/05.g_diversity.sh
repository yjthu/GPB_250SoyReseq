
bin=/data/biouser1/SOYBEAN/bin
dir=/data/biouser1/SOYBEAN/01.snp
output=/data/biouser1/SOYBEAN/05.diversity
win=100000
step=10000

echo -n "" >$output/runSitePi.sh
echo -n "" >$output/runWinPi.sh

for i in {1..20};do 
echo "vcftools --gzvcf $dir/snp/$i.snp.vcf.gz --out $output/$i --site-pi" >>$output/runSitePi.sh
echo "zcat $dir/snp/$i.snp.vcf.gz|perl $bin/vcf2MyDiversityInput.pl - >$output/$i.divinput" >>$output/runWinPi.sh
echo "perl $bin/cal_diversity_windows.pl $output/$i.divinput $output/$i.windows.pi $win $step" >>$output/runWinPi.sh
done 

echo "cat $output/*.sites.pi|grep -v 'CHROM'|awk '{sum+=\$3}END{print sum*1.0/NR}' >$output/PI.txt" >$output/runDiverStat.sh
echo "cat $output/*.windows.pi >$output/All.Windows.PI" >>$output/runDiverStat.sh
echo "perl $bin/plotPiTajimaDScat.pl $output/All.Windows.PI 0.05 >>$output/PI.txt" >>$output/runDiverStat.sh
echo "grep 'yes' $output/All.Windows.PI.plotdata |cut -f 5,6|awk '{a=\$2+100000;print \$1\":\"\$2\"-\"a}' >$output/select.regions" >>$output/runDiverStat.sh
echo "perl $bin/mergeRegions.pl $output/select.regions >$output/select.regions.merge" >>$output/runDiverStat.sh
echo "perl $bin/mergeRegionsGap.pl $output/select.regions.merge|uniq >$output/select.regions.merge2" >>$output/runDiverStat.sh
echo "perl $bin/mergeRegionsGap.pl $output/select.regions.merge2|uniq|awk '{a=$3-$2;print $0"\t"a}' >$output/select.regions.merge2.tsv" >>$output/runDiverStat.sh

list1="landrace cultivar Group1 Group2 Group3 Group4"
input=/data/biouser1/SOYBEAN/03.imputation/splitPop

echo -n "" >$output/splitChrSitePi.sh
for i in $list1;do echo "mkdir -p $output/$i" >>$output/splitChrSitePi.sh
for j in {1..20};do echo "grep '^$j\\s\\|#' $input/$i.vcf >$output/$i/$i.$j.vcf
vcftools --vcf $output/$i/$i.$j.vcf --out $output/$i/$i.$j --site-pi
perl $bin/vcf2MyDiversityInput.pl $output/$i/$i.$j.vcf >$output/$i/$i.$j.divinput
"  >>$output/splitChrSitePi.sh;done
echo "cat $output/$i/$i.*.sites.pi|grep -v 'CHROM'|grep -v nan|awk '{sum+=\$3}END{print sum*1.0/NR}' >$output/$i/$i.PI.txt" >>$output/splitChrSitePi.sh
done

list2="landrace cultivar"
echo "mkdir -p  $output/splitWinPi" >$output/splitChrWinPi.sh
for i in $list2;do
for j in {1..20};do
echo "perl $bin/cal_diversity_windows.pl $output/$i/$i.$j.divinput $output/splitWinPi/$i.$j.windows.pi $win $step" >>$output/splitChrWinPi.sh;done
echo "cat $output/splitWinPi/$i.*.windows.pi >$output/splitWinPi/$i.Windows.PI" >>$output/splitChrWinPi.sh
done
for j in {1..20};do
echo "perl $bin/cal_Fst_windows.pl $output/cultivar/cultivar.$j.divinput $output/landrace/landrace.$j.divinput $output/splitWinPi/CvsL.$j.windows.fst $win $step" >>$output/splitChrWinPi.sh
done
echo "cat $output/splitWinPi/CvsL.*.windows.fst >$output/splitWinPi/CvsL.Windows.FST" >>$output/splitChrWinPi.sh
echo "cd $output/splitWinPi
perl $bin/plotPiFstScat2.pl $output/splitWinPi/CvsL.Windows.FST landrace-cultivar 0.05
cd -"  >>$output/splitChrWinPi.sh
echo "grep 'yes' $output/splitWinPi/landrace-vs-cultivar.plotdata|cut -f 5,6|awk '{a=\$2+100000;print \$1\":\"\$2\"-\"a}' >$output/splitWinPi/Fst.select.regions" >>$output/splitChrWinPi.sh
echo "perl $bin/mergeRegions.pl $output/splitWinPi/Fst.select.regions >$output/splitWinPi/Fst.select.regions.merge" >>$output/splitChrWinPi.sh
echo "perl $bin/mergeRegionsGap.pl $output/splitWinPi/Fst.select.regions.merge|uniq >$output/splitWinPi/Fst.select.regions.merge2" >>$output/splitChrWinPi.sh



list3="Group1 Group2 Group3 Group4"
echo "mkdir -p  $output/splitSiteFst"  >$output/splitChrSiteFst.sh
for k in {1..20};do
echo "vcftools --gzvcf $dir/snp/$k.snp.vcf.gz --out $output/splitSiteFst/CvsL.$k --weir-fst-pop $input/cultivar.list --weir-fst-pop $input/landrace.list"  >>$output/splitChrSiteFst.sh
for i in $list3;do
for j in $list3;do
echo "vcftools --gzvcf $dir/snp/$k.snp.vcf.gz --out $output/splitSiteFst/$i.vs.$j.$k --weir-fst-pop $input/$i.list --weir-fst-pop $input/$j.list"  >>$output/splitChrSiteFst.sh
done
done
done

echo "cat $output/splitSiteFst/CvsL.*.weir.fst |grep -v 'CHROM'|awk '{sum+=\$3}END{print sum*1.0/NR}' >$output/splitSiteFst/CvsL.weir.FST" >>$output/splitChrSiteFst.sh

for i in $list3;do
for j in $list3;do
echo "cat $output/splitSiteFst/$i.vs.$j.*.weir.fst >$output/splitSiteFst/$i.vs.$j.weir.FST" >>$output/splitChrSiteFst.sh
echo "cat $output/splitSiteFst/$i.vs.$j.*.weir.fst|grep -v 'CHROM'|grep -v nan|awk '{sum+=\$3}END{print sum*1.0/NR}' >$output/splitSiteFst/$i.vs.$j.weir.FST" >>$output/splitChrSiteFst.sh
done
done
grep -v 'Group1.vs.Group1' $output/splitChrSiteFst.sh |grep -v 'Group2.vs.Group1'|grep -v 'Group3.vs.Group1'|grep -v 'Group4.vs.Group1'|grep -v 'Group2.vs.Group2'|grep -v 'Group3.vs.Group2'|grep -v 'Group4.vs.Group2'|grep -v 'Group3.vs.Group3'|grep -v 'Group4.vs.Group3'|grep -v 'Group4.vs.Group4' >$output/splitChrSiteFst.sh.1
mv $output/splitChrSiteFst.sh.1 $output/splitChrSiteFst.sh


