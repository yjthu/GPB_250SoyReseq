python /data/biouser1/SOYBEAN/bin/BLASTX_TO_PPI_v5.py --species 3847 --fa /data/biouser1/SOYBEAN/09.PPI/SigPeak.gene.fa --outdir /data/biouser1/SOYBEAN/09.PPI --name SoyBean

python /data/biouser1/SOYBEAN/bin/BLASTX_TO_PPI_v5.py --species 3702 --fa /data/biouser1/SOYBEAN/09.PPI/SigPeak.gene.fa --outdir /data/biouser1/SOYBEAN/09.PPI --name Ath

cat SoyBean.ppi.txt Ath.ppi.txt >cat.ppi.txt
perl ../bin/fisherTarPpi.pl ../10.GeneAnalysis/results.sig.gene.lst cat.ppi.txt |sort|uniq >SoyBean.ppi.sig

perl rmBiNet.pl SoyBean.ppi.sig >SoyBean.ppi.sig.filt

awk '{print $0"\tTrait"}' tableInput.tsv >next.info.txt

perl ../bin/appenGeneInfoPpi.pl next.info.txt ../10.GeneAnalysis/results.all.edited0429.anno.tsv ../10.GeneAnalysis/results.sig.gene.lst >ppi.gene.info

cat next.info.txt ppi.gene.info >all.info.sig
perl extractSigNet.pl ../10.GeneAnalysis/results.sig.gene.lst ../10.GeneAnalysis/results.all.edited0429.anno.tsv >gene.net.sig


perl appendInfoType.pl all.info.sig  gene.net.sig >pheno.net.sig
awk '{print $1"\t"$2"\tGene"}' SoyBean.ppi.sig.filt >SoyBean.net.sig
cat pheno.net.sig SoyBean.net.sig >all.net.sig

ls Hub/*.csv|while read a;do grep 'true' $a |cut -f 2 -d ','|sed 's/"//g' |awk '{print $1"\t'$a'"}' |sed 's#Hub/##' |sed 's/.csv//' >$a.true;done
cat Hub/*.true >Hub/Hub.group

