bin=/data/biouser1/SOYBEAN/bin
input=/data/biouser1/SOYBEAN/03.imputation
output=/data/biouser1/SOYBEAN/08.GWAS

mkdir -p $output/gwasOutput
Rscript $bin/mvp.gwas.1.R $input/plink $output

Rscript $bin/mvp.gwas.2.R $output/mvp.plink.geno.desc $output/traits.tsv $output/mvp.plink.map $output/mvp.plink.kin.desc $output/mvp.plink.pc.desc $output/gwasOutput
 
ls $output/gwasOutput/*.csv|while read a;do Rscript $bin/mvp.gwas.3.R $output/gwasOutput $a;done
